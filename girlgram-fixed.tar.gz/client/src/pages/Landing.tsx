import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Heart, Users, Palette, BookOpen, Sparkles } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-yellow-50">
      <div className="max-w-md mx-auto bg-white min-h-screen shadow-xl">
        
        {/* Header */}
        <header className="bg-gradient-to-r from-primary to-secondary p-6 text-white text-center">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
              <Heart className="text-primary text-2xl" />
            </div>
            <h1 className="text-3xl font-bold">GirlGram</h1>
          </div>
          <p className="text-lg opacity-95">Your Safe Community</p>
        </header>

        {/* Welcome Content */}
        <div className="p-6 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl text-center text-gray-800">
                Welcome to Your Digital Sisterhood! 💕
              </CardTitle>
              <CardDescription className="text-center text-gray-600">
                A safe, uplifting space designed by and for girls and young women aged 13-25
              </CardDescription>
            </CardHeader>
          </Card>

          {/* Features */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-800 text-center">Join Themed Circles</h3>
            
            <div className="grid grid-cols-1 gap-3">
              <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                <div className="w-10 h-10 bg-blue-400 rounded-full flex items-center justify-center">
                  <BookOpen className="text-white text-lg" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-800">Study & School Life</h4>
                  <p className="text-sm text-gray-600">Academic support and study tips</p>
                </div>
              </div>

              <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                <div className="w-10 h-10 bg-green-400 rounded-full flex items-center justify-center">
                  <Heart className="text-white text-lg" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-800">Mental Wellness & Self-Care</h4>
                  <p className="text-sm text-gray-600">Mental health and wellness support</p>
                </div>
              </div>

              <div className="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
                <div className="w-10 h-10 bg-purple-400 rounded-full flex items-center justify-center">
                  <Palette className="text-white text-lg" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-800">Creative Space</h4>
                  <p className="text-sm text-gray-600">Art, writing, music and creativity</p>
                </div>
              </div>

              <div className="flex items-center space-x-3 p-3 bg-pink-50 rounded-lg">
                <div className="w-10 h-10 bg-pink-400 rounded-full flex items-center justify-center">
                  <Sparkles className="text-white text-lg" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-800">Style & Beauty</h4>
                  <p className="text-sm text-gray-600">Fashion and beauty discussions</p>
                </div>
              </div>

              <div className="flex items-center space-x-3 p-3 bg-yellow-50 rounded-lg">
                <div className="w-10 h-10 bg-yellow-400 rounded-full flex items-center justify-center">
                  <Users className="text-white text-lg" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-800">College & Career</h4>
                  <p className="text-sm text-gray-600">Career advice and college prep</p>
                </div>
              </div>
            </div>
          </div>

          {/* Community Guidelines */}
          <Card className="border-2 border-green-200 bg-green-50">
            <CardHeader>
              <CardTitle className="text-lg text-green-800">🛡️ Safe Space Promise</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-green-700">
              <p>✨ Be kind & respectful to everyone</p>
              <p>💖 Support each other with encouragement</p>
              <p>🚫 Zero tolerance for bullying or hate</p>
              <p>🔒 Moderated for your safety</p>
            </CardContent>
          </Card>

          {/* Login Button */}
          <div className="pt-4">
            <Button 
              onClick={handleLogin}
              className="w-full bg-gradient-to-r from-primary to-secondary hover:from-pink-500 hover:to-purple-500 text-white py-3 text-lg font-medium"
              size="lg"
            >
              Join GirlGram ✨
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
