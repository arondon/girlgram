import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MessageCircle, Heart } from "lucide-react";

export default function Messages() {
  return (
    <Layout>
      <div className="pb-20">
        {/* Header */}
        <div className="bg-gradient-to-r from-primary to-secondary p-6 text-white">
          <div className="flex items-center space-x-3">
            <MessageCircle className="w-8 h-8" />
            <div>
              <h1 className="text-2xl font-bold">Messages</h1>
              <p className="text-white/80">Connect with your community</p>
            </div>
          </div>
        </div>

        <div className="p-4">
          {/* Coming Soon */}
          <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-3">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <CardTitle className="text-2xl text-gray-800">Coming Soon! 💕</CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <p className="text-gray-700">
                We're working on a beautiful messaging system that will let you:
              </p>
              
              <div className="space-y-3 text-left">
                <div className="flex items-center space-x-3 p-3 bg-white rounded-lg">
                  <span className="text-purple-500">💬</span>
                  <span className="text-gray-700">Send private messages to friends</span>
                </div>
                
                <div className="flex items-center space-x-3 p-3 bg-white rounded-lg">
                  <span className="text-pink-500">👥</span>
                  <span className="text-gray-700">Create group chats with circle members</span>
                </div>
                
                <div className="flex items-center space-x-3 p-3 bg-white rounded-lg">
                  <span className="text-blue-500">🔔</span>
                  <span className="text-gray-700">Get real-time notifications</span>
                </div>
                
                <div className="flex items-center space-x-3 p-3 bg-white rounded-lg">
                  <span className="text-green-500">🛡️</span>
                  <span className="text-gray-700">Enjoy safe, moderated conversations</span>
                </div>
              </div>
              
              <div className="pt-4">
                <p className="text-sm text-gray-600">
                  Stay tuned for updates! In the meantime, connect through posts and comments. ✨
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Safety Note */}
          <Card className="mt-6 border-2 border-yellow-200 bg-yellow-50">
            <CardHeader>
              <CardTitle className="text-lg text-yellow-800 flex items-center">
                🛡️ Safety First
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-yellow-700">
              <p>🚫 Never share personal information like your address or phone number</p>
              <p>👩‍👧 Don't arrange to meet anyone from the app in person</p>
              <p>📱 Report any inappropriate messages immediately</p>
              <p>💖 Remember: true friends respect your boundaries</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
