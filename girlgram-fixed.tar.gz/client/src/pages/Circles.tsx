import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Users, UserPlus, UserMinus } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { Circle } from "@shared/schema";

export default function Circles() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch all circles
  const { 
    data: circles = [], 
    isLoading: circlesLoading 
  } = useQuery<Circle[]>({
    queryKey: ["/api/circles"],
  });

  // Fetch user circles
  const { 
    data: userCircles = [] 
  } = useQuery<Circle[]>({
    queryKey: ["/api/circles/user"],
    enabled: !!user,
  });

  // Join/leave circle mutation
  const circleMutation = useMutation({
    mutationFn: async ({ circleId, action }: { circleId: number; action: "join" | "leave" }) => {
      if (action === "join") {
        await apiRequest("POST", `/api/circles/${circleId}/join`);
      } else {
        await apiRequest("DELETE", `/api/circles/${circleId}/leave`);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/circles/user"] });
      toast({
        title: "Success",
        description: "Circle membership updated!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update circle membership",
        variant: "destructive",
      });
    },
  });

  const isJoined = (circleId: number) => {
    return userCircles.some(uc => uc.id === circleId);
  };

  const handleCircleAction = (circleId: number) => {
    const action = isJoined(circleId) ? "leave" : "join";
    circleMutation.mutate({ circleId, action });
  };

  const getCircleIcon = (iconName?: string | null) => {
    switch (iconName) {
      case "fas fa-book": return "📚";
      case "fas fa-heart": return "💖";
      case "fas fa-palette": return "🎨";
      case "fas fa-sparkles": return "✨";
      case "fas fa-graduation-cap": return "🎓";
      default: return "🌟";
    }
  };

  const getCircleColor = (colorName?: string | null) => {
    switch (colorName) {
      case "blue": return "bg-blue-100 border-blue-300";
      case "green": return "bg-green-100 border-green-300";
      case "purple": return "bg-purple-100 border-purple-300";
      case "pink": return "bg-pink-100 border-pink-300";
      case "yellow": return "bg-yellow-100 border-yellow-300";
      default: return "bg-gray-100 border-gray-300";
    }
  };

  return (
    <Layout>
      <div className="pb-20">
        {/* Header */}
        <div className="bg-gradient-to-r from-primary to-secondary p-6 text-white">
          <div className="flex items-center space-x-3">
            <Users className="w-8 h-8" />
            <div>
              <h1 className="text-2xl font-bold">Circles</h1>
              <p className="text-white/80">Join communities that inspire you</p>
            </div>
          </div>
        </div>

        <div className="p-4 space-y-6">
          {/* My Circles */}
          <div>
            <h2 className="text-lg font-semibold text-gray-800 mb-3">
              My Circles ({userCircles.length})
            </h2>
            
            {userCircles.length === 0 ? (
              <Card className="border-dashed border-2 border-gray-300">
                <CardContent className="pt-6 text-center text-gray-500">
                  <Users className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                  <p>You haven't joined any circles yet!</p>
                  <p className="text-sm">Explore the circles below to get started.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-3">
                {userCircles.map((circle) => (
                  <Card key={circle.id} className={`border-2 ${getCircleColor(circle.color)}`}>
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <span className="text-2xl">{getCircleIcon(circle.icon)}</span>
                          <div>
                            <CardTitle className="text-lg">{circle.name}</CardTitle>
                            <CardDescription>{circle.description}</CardDescription>
                          </div>
                        </div>
                        <Badge variant="secondary">Joined</Badge>
                      </div>
                    </CardHeader>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* All Circles */}
          <div>
            <h2 className="text-lg font-semibold text-gray-800 mb-3">
              Discover Circles
            </h2>
            
            {circlesLoading ? (
              <div className="space-y-3">
                {[...Array(5)].map((_, i) => (
                  <Skeleton key={i} className="h-24 w-full" />
                ))}
              </div>
            ) : (
              <div className="space-y-3">
                {circles.map((circle) => (
                  <Card key={circle.id} className="border-2 border-gray-200">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <span className="text-2xl">{getCircleIcon(circle.icon)}</span>
                          <div>
                            <CardTitle className="text-lg">{circle.name}</CardTitle>
                            <CardDescription>{circle.description}</CardDescription>
                          </div>
                        </div>
                        
                        <Button
                          variant={isJoined(circle.id) ? "outline" : "default"}
                          size="sm"
                          onClick={() => handleCircleAction(circle.id)}
                          disabled={circleMutation.isPending}
                          className={isJoined(circle.id) 
                            ? "text-red-600 border-red-300 hover:bg-red-50" 
                            : "bg-gradient-to-r from-primary to-secondary hover:from-pink-500 hover:to-purple-500"
                          }
                        >
                          {isJoined(circle.id) ? (
                            <>
                              <UserMinus className="w-4 h-4 mr-1" />
                              Leave
                            </>
                          ) : (
                            <>
                              <UserPlus className="w-4 h-4 mr-1" />
                              Join
                            </>
                          )}
                        </Button>
                      </div>
                    </CardHeader>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* Community Guidelines */}
          <Card className="border-2 border-green-200 bg-green-50">
            <CardHeader>
              <CardTitle className="text-lg text-green-800 flex items-center">
                🛡️ Circle Guidelines
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-green-700">
              <p>✨ Keep discussions respectful and on-topic</p>
              <p>💖 Support and encourage fellow members</p>
              <p>🚫 No bullying, harassment, or inappropriate content</p>
              <p>📱 Report any concerning behavior to moderators</p>
              <p>🌟 Share resources and help others grow</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
