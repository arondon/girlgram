import { useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Layout from "@/components/Layout";
import PostCard from "@/components/PostCard";
import CreatePost from "@/components/CreatePost";
import CircleIcon from "@/components/CircleIcon";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { PostWithAuthorAndCircle, Circle } from "@shared/schema";

export default function Home() {
  const { user, isLoading: userLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Initialize app data
  useEffect(() => {
    apiRequest("GET", "/api/init").catch(console.error);
  }, []);

  // Fetch feed posts
  const { 
    data: posts = [], 
    isLoading: postsLoading,
    error: postsError 
  } = useQuery<PostWithAuthorAndCircle[]>({
    queryKey: ["/api/posts/feed"],
    enabled: !!user,
  });

  // Fetch circles
  const { 
    data: circles = [], 
    isLoading: circlesLoading 
  } = useQuery<Circle[]>({
    queryKey: ["/api/circles"],
  });

  // Fetch user circles
  const { 
    data: userCircles = [] 
  } = useQuery<Circle[]>({
    queryKey: ["/api/circles/user"],
    enabled: !!user,
  });

  // Like/unlike mutation
  const likeMutation = useMutation({
    mutationFn: async ({ postId, isLiked }: { postId: number; isLiked: boolean }) => {
      const method = isLiked ? "DELETE" : "POST";
      await apiRequest(method, `/api/posts/${postId}/like`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts/feed"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update like status",
        variant: "destructive",
      });
    },
  });

  const handleLike = (postId: number, isLiked: boolean) => {
    likeMutation.mutate({ postId, isLiked });
  };

  // Handle unauthorized errors for posts
  useEffect(() => {
    if (postsError && isUnauthorizedError(postsError)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [postsError, toast]);

  if (userLoading) {
    return (
      <Layout>
        <div className="p-4 space-y-4">
          <Skeleton className="h-20 w-full" />
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-48 w-full" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      {/* Circles Quick Access */}
      <section className="p-4 lg:p-6 bg-white border-b border-gray-100">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold text-gray-800">Your Circles</h2>
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-secondary hover:text-secondary/80"
          >
            View All
          </Button>
        </div>
        
        {circlesLoading ? (
          <div className="flex space-x-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex-shrink-0 text-center">
                <Skeleton className="w-16 h-16 rounded-full mb-2" />
                <Skeleton className="h-3 w-12" />
              </div>
            ))}
          </div>
        ) : (
          <div className="flex space-x-3 overflow-x-auto pb-2 lg:grid lg:grid-cols-6 lg:gap-4 lg:overflow-visible">
            {circles.map((circle) => (
              <CircleIcon 
                key={circle.id} 
                circle={circle}
                isJoined={userCircles.some(uc => uc.id === circle.id)}
              />
            ))}
          </div>
        )}
      </section>

      {/* Create Post */}
      <CreatePost />

      {/* Feed */}
      <main className="pb-20">
        {postsLoading ? (
          <div className="space-y-4 p-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-white p-4 space-y-3">
                <div className="flex items-start space-x-3">
                  <Skeleton className="w-12 h-12 rounded-full" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-4 w-1/3" />
                    <Skeleton className="h-16 w-full" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : posts.length === 0 ? (
          <div className="p-8 text-center text-gray-500">
            <p className="text-lg mb-2">Welcome to GirlGram! 🌟</p>
            <p>No posts yet. Be the first to share something!</p>
          </div>
        ) : (
          <div>
            {posts.map((post) => (
              <PostCard 
                key={post.id} 
                post={post} 
                onLike={handleLike}
                isLiking={likeMutation.isPending}
              />
            ))}
          </div>
        )}
      </main>
    </Layout>
  );
}
