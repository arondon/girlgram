import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Layout from "@/components/Layout";
import PostCard from "@/components/PostCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Edit, Save, X } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { PostWithAuthorAndCircle, User } from "@shared/schema";

export default function Profile() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    firstName: "",
    lastName: "",
    age: "",
    bio: "",
  });

  // Fetch user posts
  const { 
    data: posts = [], 
    isLoading: postsLoading 
  } = useQuery<PostWithAuthorAndCircle[]>({
    queryKey: ["/api/posts/user", user?.id],
    enabled: !!user,
  });

  // Update profile mutation
  const updateMutation = useMutation({
    mutationFn: async (data: Partial<User>) => {
      await apiRequest("PATCH", "/api/auth/user", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      setIsEditing(false);
      toast({
        title: "Success",
        description: "Profile updated successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive",
      });
    },
  });

  const handleEdit = () => {
    setEditForm({
      firstName: user?.firstName || "",
      lastName: user?.lastName || "",
      age: user?.age?.toString() || "",
      bio: user?.bio || "",
    });
    setIsEditing(true);
  };

  const handleSave = () => {
    const data: Partial<User> = {
      firstName: editForm.firstName || null,
      lastName: editForm.lastName || null,
      age: editForm.age ? parseInt(editForm.age) : null,
      bio: editForm.bio || null,
    };

    // Validate age
    if (data.age && (data.age < 13 || data.age > 25)) {
      toast({
        title: "Invalid Age",
        description: "Age must be between 13 and 25",
        variant: "destructive",
      });
      return;
    }

    updateMutation.mutate(data);
  };

  const handleCancel = () => {
    setIsEditing(false);
    setEditForm({
      firstName: "",
      lastName: "",
      age: "",
      bio: "",
    });
  };

  const displayName = user?.firstName && user?.lastName 
    ? `${user.firstName} ${user.lastName}`
    : user?.firstName || user?.email || "User";

  return (
    <Layout>
      <div className="pb-20">
        {/* Profile Header */}
        <div className="bg-gradient-to-r from-primary to-secondary p-6 text-white">
          <div className="flex items-center space-x-4">
            <img
              src={user?.profileImageUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(displayName)}&background=random`}
              alt="Profile"
              className="w-20 h-20 rounded-full object-cover border-4 border-white"
            />
            <div className="flex-1">
              <h1 className="text-2xl font-bold">{displayName}</h1>
              {user?.email && (
                <p className="text-white/80">{user.email}</p>
              )}
              {user?.age && (
                <p className="text-white/80">Age: {user.age}</p>
              )}
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={isEditing ? handleCancel : handleEdit}
              className="text-white hover:bg-white/20"
            >
              {isEditing ? <X className="w-4 h-4" /> : <Edit className="w-4 h-4" />}
            </Button>
          </div>
        </div>

        {/* Profile Details */}
        <div className="p-4 space-y-4">
          {isEditing ? (
            <Card>
              <CardHeader>
                <CardTitle>Edit Profile</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-sm font-medium text-gray-700">First Name</label>
                    <Input
                      value={editForm.firstName}
                      onChange={(e) => setEditForm(prev => ({ ...prev, firstName: e.target.value }))}
                      placeholder="First name"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Last Name</label>
                    <Input
                      value={editForm.lastName}
                      onChange={(e) => setEditForm(prev => ({ ...prev, lastName: e.target.value }))}
                      placeholder="Last name"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700">Age (13-25)</label>
                  <Input
                    type="number"
                    min={13}
                    max={25}
                    value={editForm.age}
                    onChange={(e) => setEditForm(prev => ({ ...prev, age: e.target.value }))}
                    placeholder="Your age"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-700">Bio</label>
                  <Textarea
                    value={editForm.bio}
                    onChange={(e) => setEditForm(prev => ({ ...prev, bio: e.target.value }))}
                    placeholder="Tell us about yourself..."
                    rows={3}
                  />
                </div>

                <Button 
                  onClick={handleSave}
                  disabled={updateMutation.isPending}
                  className="w-full bg-gradient-to-r from-primary to-secondary"
                >
                  <Save className="w-4 h-4 mr-2" />
                  {updateMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>About</CardTitle>
              </CardHeader>
              <CardContent>
                {user?.bio ? (
                  <p className="text-gray-700">{user.bio}</p>
                ) : (
                  <p className="text-gray-500 italic">No bio yet. Click edit to add one!</p>
                )}
                
                {user?.interests && user.interests.length > 0 && (
                  <div className="mt-4">
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Interests</h4>
                    <div className="flex flex-wrap gap-2">
                      {user.interests.map((interest, index) => (
                        <Badge key={index} variant="secondary">
                          {interest}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* User Stats */}
          <Card>
            <CardHeader>
              <CardTitle>Your Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <p className="text-2xl font-bold text-primary">{posts.length}</p>
                  <p className="text-sm text-gray-600">Posts</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-secondary">{posts.reduce((sum, post) => sum + post.likesCount, 0)}</p>
                  <p className="text-sm text-gray-600">Likes Received</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-accent">{posts.reduce((sum, post) => sum + post.commentsCount, 0)}</p>
                  <p className="text-sm text-gray-600">Comments</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* User Posts */}
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Your Posts</h3>
            
            {postsLoading ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <Skeleton key={i} className="h-32 w-full" />
                ))}
              </div>
            ) : posts.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <p>You haven't posted anything yet!</p>
                <p className="text-sm">Share your first post to get started 🌟</p>
              </div>
            ) : (
              <div className="space-y-4">
                {posts.map((post) => (
                  <PostCard key={post.id} post={post} onLike={() => {}} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
